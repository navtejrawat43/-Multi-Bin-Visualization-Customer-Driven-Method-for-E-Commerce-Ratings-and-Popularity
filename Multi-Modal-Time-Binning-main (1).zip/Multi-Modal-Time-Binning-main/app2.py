import dash
import plotly.express as px
import pandas as pd
from dash import Dash, html, dcc
from dash.dependencies import Output, Input  
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime as dt, timedelta
import plotly.graph_objects as go

df = pd.read_csv('sorted_file.csv')

df['Processed_Date'] = pd.to_datetime(df['Processed_Date'])

df_long = pd.DataFrame(df)


# Aggregate the data by counting occurrences 
#Converting to wide-format for plotly express
df_aggregated = df_long.groupby(['Processed_Date', 'Ratings']).size().unstack(fill_value=0).reset_index()

# Rename columns for clarity
df_aggregated.columns.name = None  # Remove column name
df_aggregated = df_aggregated.rename(columns={1.0: 'Rating_1', 2.0: 'Rating_2', 3.0: 'Rating_3', 4.0: 'Rating_4', 5.0: 'Rating_5'})

# print(df_aggregated)
df_aggregated = df_aggregated.drop([11,12,13,14])
df_aggregated.reset_index(drop=True, inplace=True)
df_aggregated['Total Votes'] = df_aggregated[['Rating_1','Rating_2',  'Rating_3', 'Rating_4',  'Rating_5']].sum(axis=1)

df_aggregated['Average Rating'] = None
df_aggregated['Color'] = None
df_aggregated['Log2(Total Votes)'] = None
for index, row in df_aggregated.iterrows():

    rating_weight = 0.0
    for rating in (['Rating_1','Rating_2',  'Rating_3', 'Rating_4',  'Rating_5']):
        rating_weight += float(rating[7:])*row[rating]
    df_aggregated.at[index,'Color'] = 1
    if row['Total Votes'] != 0:
        df_aggregated.at[index, 'Average Rating'] = rating_weight / row['Total Votes']
        df_aggregated.at[index, 'Log2(Total Votes)'] = np.log2(row['Total Votes'])
    else:
        df_aggregated.at[index, 'Average Rating'] = 0.0
        df_aggregated.at[index, 'Log2(Total Votes)'] = 0


#-----------------------------------------LoR-------------------------------------------------  

df_aggregated['Y'] = None
def regression():
    pass


#-----------------------------------------LoR------------------------------------------------  



# Oct-22 to Feb23 Total Votes
# df_aggregated['Y'] = None
# for index, row in df_aggregated.iterrows():
#     print(index)
#     df_aggregated.at[index,'Y2'] = (index+1)*-1*1.100 + 21.50

# FEB-23 to Aug-23 TOTAL VOTES
df_aggregated['Y1'] = None
for index, row in df_aggregated.iterrows():
    print(index)
    df_aggregated.at[index,'Y1'] = (index+1)*-1*0.8571 + 10.33

# # Average Rating  OCt-22 to April-23
# df_aggregated['Y2'] = None
# for index, row in df_aggregated.iterrows():
#     print(index)
#     df_aggregated.at[index,'Y2'] = (index+1)*-1*0.1418 + 5.094

# # Average Rating  Apr-22 to Aug-23
# df_aggregated['Y3'] = None
# for index, row in df_aggregated.iterrows():
#     print(index)
#     df_aggregated.at[index,'Y3'] = (index+1)*-1*0.1700 + 5.200




# print(df_aggregated.columns)


# print(df_aggregated)

#Drop outliers

app = dash.Dash(__name__)

app.layout = html.Div([
    html.Div([
    html.H1("Multimodal-Time-Binning"),
#Plot-1
html.H3("Choose-Epoch"),
    dcc.Dropdown(id='Epoch',
                 options=[{'label': x , 'value': x}
                          for x in ([1,2,3,4,5,6,7,8,9,10,11,12])],
                 value=12 # default value
                 ),
    dcc.Graph(id='python-graph', figure={}),

# #Plot-2    
# html.H3("Choose Epoch"),
#     dcc.Dropdown(id = 'Epoch2',
#                   options=[{'label': x , 'value': x}
#                           for x in ([1,2,3,4,5,6,7,8,9,10,11,12])],
#                  value=12  # default value
#                  ),
#     dcc.Graph(id='python-graph2', figure={}),

#Plot-3
html.H3("Choose Epoch"),
    dcc.Dropdown(id = 'Epoch3',
                  options=[{'label': x , 'value': x}
                          for x in ([1,2,3,4,5,6,7,8,9,10,11,12])],
                 value=12 # default value
                 ),
    dcc.Graph(id='python-graph3', figure={}),
    #Plot-4
html.H3("Choose Epoch"),
    dcc.Dropdown(id = 'Epoch4',
                  options=[{'label': x , 'value': x}
                          for x in ([1])],
                 value=1  # default value
                 ),
    dcc.Graph(id='python-graph4', figure={}),
    ])
])





#-----------------------------------------PLOT-1-------------------------------------------------  
#-----------------------------------------PLOT-1-------------------------------------------------  
@app.callback(
    Output(component_id='python-graph', component_property='figure'),
     [Input(component_id='Epoch', component_property='value')]
)
# callbackfunction
def interactive(epoch_value):
    # global df_aggregated
    # end_date = pd.to_datetime(dt.now())
    # start_date = pd.to_datetime(end_date - pd.DateOffset(months=epoch_value+2))
    
    # new = df_aggregated[(df_aggregated['Processed_Date'] >= start_date) & (df_aggregated['Processed_Date']<= end_date)]
    # rating_labels = ['Rating_1', 'Rating_2', 'Rating_3', 'Rating_4', 'Rating_5']



    # fig = go.Figure(data=[go.Bar(
    #     x=rating_labels,
    #     y=df_aggregated['Total Votes'],
    #     marker_color='black'  # Set the bar color to black
    # )])

    # fig.update_layout(title_text='Least Used Feature')
    # return fig
    #-----------------------------------------PLOT-1-------------------------------------------------  
    end_date = pd.to_datetime(dt.now())
    start_date = pd.to_datetime(end_date - pd.DateOffset(months=epoch_value+2))
    
    new = df_aggregated[(df_aggregated['Processed_Date'] >= start_date) & (df_aggregated['Processed_Date']<= end_date)]
    fig = px.bar(new, x='Processed_Date', y=['Rating_1', 'Rating_2', 'Rating_3', 'Rating_4', 'Rating_5'],
            # color = "",
            color_discrete_sequence=["#D3D3D3", "#A9A9A9", "#808000", "#36454F", "#8B6969"  ],
             labels={'Processed_Date': 'Date', 'value': 'Count'},
             title='Number of Votes for Each Rating Over Time',
             barmode='group') 
    fig.update_traces(width = 100000000)
    
     
    fig.add_trace(go.Scatter(x=new['Processed_Date'], y=new['Total Votes'], mode='markers', name='Total Votes',marker_symbol = 'x', marker_color = "black"))
    
    line_trace = px.line(new, x='Processed_Date', y='Total Votes', line_shape="linear").data[0]
    line_trace['line']['color'] = 'grey'  # Set the line color to red
    fig.add_trace(line_trace)

    return fig
#---------------------------------------------------------------------------------------------  

#-----------------------------------------PLOT-2.0----------------------------------------------  
# @app.callback(
#     Output(component_id='python-graph2', component_property='figure'),
#      [Input(component_id='Epoch2', component_property='value')]
# )

# def interactive(epoch_value):
#     # global df
    
#     end_date = pd.to_datetime(dt.now())
#     start_date = pd.to_datetime(end_date - pd.DateOffset(months=epoch_value+2))
#     new= df_aggregated[(df_aggregated['Processed_Date'] >= start_date) & (df_aggregated['Processed_Date']<= end_date)]
#     # new2 = n
#     # print(new)
#     # print(df_aggregated)
#     # fig = px.scatter(new, x='Processed_Date', y=['Average Rating','Total Votes'], hover_name="Total Votes",
#     #              opacity=0.5, labels={'Processed_Date': 'Date'}, color_discrete_map={}, title='Average Rating Over Time',)
#     fig = go.Figure(go.Scatter(x=new['Processed_Date'], y=new['Average Rating'], marker_symbol='circle-open', marker_line_color="black", marker_color="black", mode='markers', name='Average Rating', yaxis="y"))
#     # fig.add_trace(px.line(new, x='Processed_Date', y='Average Rating', line_shape="linear").data[0])
#     # fig.add_trace(go.Scatter(x=df['X3'], y=df['Y3'], mode='markers', name='Scatter 3'))

    
#     # fig.add_trace(px.line(new, x='Month', y='Total Votes', line_shape="linear" ).data[0])


#     fig.update_traces(marker=dict(size=12))
#     return fig
#--------------------------------------------------------------------------------------------- 

#----------------------------------------PLOT-2------------------------------------------------  
@app.callback(
    Output(component_id='python-graph3', component_property='figure'),
     [Input(component_id='Epoch3', component_property='value')]
)

def interactive(epoch_value):
    # global df
    symbols = ['x']
    
    end_date = pd.to_datetime(dt.now())
    start_date = pd.to_datetime(end_date - pd.DateOffset(months=epoch_value+2))
    new= df_aggregated[(df_aggregated['Processed_Date'] >= start_date) & (df_aggregated['Processed_Date']<= end_date)]


    # new['Y1'] = None
    # for index, row in new.iterrows():
    #     print(index)
    #     new.at[index,'Y1'] = (index+1)*-1*0.8571 + 10.33
    
    
    # print(df_aggregated)
    # fig = px.scatter(new, x='Processed_Date', y=['Average Rating'], hover_name="Total Votes",
    #              opacity=0.5, labels={'Processed_Date': 'Date'}, color_discrete_map={}, title='Average Rating Over Time',trendline="Average Rating")
    # line_trace = px.line(new, x='Processed_Date', y='Average Rating', line_shape="linear").data[0]
    # line_trace['line']['color'] = 'red'  # Set the line color to red
    # fig.add_trace(line_trace)
    
    fig = go.Figure(go.Scatter(x=new['Processed_Date'], y=new['Average Rating'], marker_symbol='circle', marker_line_color="black", marker_color="black", mode='markers', name='Average Rating', yaxis="y"))
    # return fig
    fig.add_trace(go.Scatter(x=new['Processed_Date'], y=new['Total Votes'], marker_symbol='x-thin-open',marker_color="black", mode='markers', name='Total Votes', yaxis="y2"))
    # print(fig.data[1])
    new2 = new[(new['Processed_Date'] >= '2022-10-01') & (new['Processed_Date'] <= '2023-02-01')]
    new3 = new[(new['Processed_Date'] >= '2023-02-01') & (new['Processed_Date'] <= '2023-08-01')]
    
    # fig2 = px.scatter(new2, x="Processed_Date", y="Total Votes", trendline="ols")
    # Oct-22 to Feb23------------------------------------------------------------[Y]  Total Votes LOR-----------------
    new2['Y'] = None
    for index, row in new.iterrows():
        print(index)
        new2.at[index,'Y'] = (index+1-19)*-1*1.100 + 21.50
    print(new2)
    # ----------------------------------------------------------------------------------------------------------------
    # fig.add_trace(go.Line(x=new2['Processed_Date'], y=new2['Y'], name='Total Votes', yaxis="y2"))
    # fig.add_trace(
    #     go.Scatter(
    #         x=new2['Processed_Date'],
    #         y=new2['Y'],  # Assuming 'Y' is the column with regression values
    #         mode='lines',
    #         line=dict(color='red', dash='dash'),  # Adjust line color and dash style as needed
    #         name='Regression Line',
    #         yaxis="y"
    #     )
    # )
    # fig.add_trace(go.Line(x=new3['Processed_Date'], y=new3['Y2'], name='Total Votes', yaxis="y2"))
    
    # fig.add_trace(go.Scatter(x=new2['Processed_Date'], y=new2['Y'], marker_symbol='x-thin',marker_color="black", mode='markers',name = 'Line of Regression', yaxis="y"))
    # line_trace = px.line(new2, x='Processed_Date', y='Y', line_shape="linear").data[0]
    # line_trace['line']['color'] = 'black'  # Set the line color to red
    # fig.add_trace(line_trace)
    fig.update_layout(yaxis=dict(
        title="Average Rating",
        side = 'right',
        titlefont=dict(
            color="black"
        ),
        tickfont=dict(
            color="#000000"
        )
    ),
     yaxis2=dict(
        title="Total Votes",
        titlefont=dict(
            color="#000000"
        ),
        tickfont=dict(
            color="#000000"
        ),
        anchor="free",
        overlaying="y",
        side="left",
        
    ),)
 
    

    # fig.add_trace(go.Scatter(x=df['X3'], y=df['Y3'], mode='markers', name='Scatter 3'))

    
    # fig.add_trace(px.line(new, x='Month', y='Total Votes', line_shape="linear" ).data[0])


    fig.update_traces(marker=dict(size=12))
    return fig
#--------------------------------------------------------------------------------------------- 

#--------------------------------------PLOT-3-------------------------------------------------  
@app.callback(
    Output(component_id='python-graph4', component_property='figure'),
     [Input(component_id='Epoch4', component_property='value')]
)
# callbackfunction
def interactive(epoch_value):
    # global df_aggregated
    # end_date = pd.to_datetime(dt.now())
    # start_date = pd.to_datetime(end_date - pd.DateOffset(months=epoch_value+2))
    
    new = df_aggregated
    # fig = px.bar(new, x='Processed_Date', y=['Rating_1', 'Rating_2', 'Rating_3', 'Rating_4', 'Rating_5'],
    #          labels={'Processed_Date': 'Date', 'value': 'Count'},
    #          title='Vendor-Side Graph',
    #          color_discrete_sequence=["black","black","black","black","black"],
    #          barmode='group')  
    highlight_interval = dict(x0='2020-11-01', x1='2022-02-01', color='cyan', opacity=0.3)
    highlight_interval2 = dict(x0='2022-02-01', x1='2022-02-03', color='black', opacity=0.3)
    # highlight_interval3 = dict(x0='2022-02-01', x1='2022-03-01', color='violet', opacity=0.3)
    # highlight_interval3 = dict(x0='2021-06-01', x1='2022-02-01', color='cyan', opacity=0.3)

    fig = go.Figure()

    # Create a Scatter trace for the date range '2020-11-01' to '2022-02-01'
    fig.add_trace(
        go.Scatter(
            x=df_aggregated[(df_aggregated['Processed_Date'] >= '2020-11-01') & (df_aggregated['Processed_Date'] <= '2022-02-01')]['Processed_Date'],
            y=df_aggregated[(df_aggregated['Processed_Date'] >= '2020-11-01') & (df_aggregated['Processed_Date'] <='2022-02-01')]['Total Votes'],
            mode='markers',
            marker_symbol='x-thin-open',
            marker=dict(color='black'),
            name='Total Votes (2020-11-01 to 2022-02-01)'
        )
    )

    # Create a Scatter trace for the date range '2022-02-01' to '2023-08-01'
    fig.add_trace(
        go.Scatter(
            x=df_aggregated[(df_aggregated['Processed_Date'] > '2022-02-01') & (df_aggregated['Processed_Date'] < '2023-08-01')]['Processed_Date'],
            y=df_aggregated[(df_aggregated['Processed_Date'] > '2022-02-01') & (df_aggregated['Processed_Date'] < '2023-08-01')]['Total Votes'],
            mode='markers',
            marker_symbol = 'x-thin-open',
            marker=dict(color='black'),
            
            name='Total Votes (2022-02-01 to 2023-08-01)'
        )
    )# Add a shape for the highlighted interval
    fig.add_shape(
        type="rect",
        x0=highlight_interval['x0'],
        x1=highlight_interval['x1'],
        y0=0,
        y1=0,  # This value is in relative coordinates (0 to 1)
        fillcolor=highlight_interval['color'],
        opacity=highlight_interval['opacity'],
        line=dict(width=0),
        layer="below"
    ) 
    fig.add_shape(
        type="rect",
        x0=highlight_interval2['x0'],
        x1=highlight_interval2['x1'],
        y0=0,
        y1=150,  # This value is in relative coordinates (0 to 1)
        fillcolor=highlight_interval2['color'],
        opacity=highlight_interval2['opacity'],
        line=dict(width=0),
        layer="below"
    ) 
    line2 = px.line(new, x='Processed_Date', y='Total Votes', line_shape="linear").data[0]
    line2['line']['width'] = 0.3
    fig.add_trace(line2) 
    line_trace = px.line(new, x='Processed_Date', y='Total Votes', line_shape="linear").data[0]
    # line_trace['line']['color'] = 'black'  # Set the line color to red
    line_trace['line']['width'] = 0.3
    fig.add_trace(line_trace)


    return fig

#--------------------------------------------------------------------------------------------- 
        
    



if __name__ == '__main__':
    app.run_server(debug=True, port=8002)















