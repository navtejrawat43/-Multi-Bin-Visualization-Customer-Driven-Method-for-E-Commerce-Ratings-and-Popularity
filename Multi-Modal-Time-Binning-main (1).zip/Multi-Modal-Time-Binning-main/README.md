# Multi-Modal-Time-Binning
Product 1 URL - "https://www.flipkart.com/apple-iphone-12-black-64-gb/product-reviews/itma2559422bf7c7?pid=MOBFWBYZU5FWK2VP&lid=LSTMOBFWBYZU5FWK2VPFMEI56&marketplace=FLIPKART"

RUN in the order

1) flip.py

2) clean_csv.py

3) clean_csv2.py

Final-Dataset - sorted.csv


Change iterations in Line-34 in flip.py to scrape more reviews.

Run app2.py in /User Interface


